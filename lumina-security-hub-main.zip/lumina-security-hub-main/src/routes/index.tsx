import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Phone, MapPin, Clock, Menu, X, ShieldCheck, Camera, Wrench, HardDrive,
  Network, Eye, Star, MessageCircle, Mail, ArrowRight, Sparkles, Award,
  Users, Package, Headphones, PlayCircle, Facebook, Instagram, Youtube,
} from "lucide-react";
import aboutSide from "@/assets/about-side.jpg";
import gal1 from "@/assets/gallery-1.jpg";
import gal2 from "@/assets/gallery-2.jpg";
import gal3 from "@/assets/gallery-3.jpg";
import gal4 from "@/assets/gallery-4.jpg";
import gal5 from "@/assets/gallery-5.jpg";
import camRight from "@/assets/cam-right.png";
import camLeft from "@/assets/cam-left.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VioVision — Wholesale CCTV & Security Solutions" },
      {
        name: "description",
        content:
          "Trusted wholesale CCTV cameras, DVR/NVR systems and security solutions at unbeatable prices. Bulk orders, expert support and pan-India delivery.",
      },
      { property: "og:title", content: "VioVision — Wholesale CCTV & Security Solutions" },
      { property: "og:description", content: "Reliable products, wholesale pricing and trusted support." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Home,
});

const PHONE = "+91 99999 99999";
const PHONE_TEL = "+919999999999";
const WHATSAPP = "919999999999";

/* ---------- shared bits ---------- */

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function BackgroundFX() {
  return (
    <div aria-hidden className="fixed inset-0 -z-10 overflow-hidden">
      <div className="blob animate-float" style={{ width: 520, height: 520, top: -120, left: -100, background: "oklch(0.55 0.28 305 / 0.55)" }} />
      <div className="blob animate-float-slow" style={{ width: 600, height: 600, top: "30%", right: -180, background: "oklch(0.45 0.25 285 / 0.5)" }} />
      <div className="blob animate-float" style={{ width: 480, height: 480, bottom: -160, left: "30%", background: "oklch(0.5 0.26 320 / 0.45)" }} />
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(oklch(1 0 0 / 0.5) 1px, transparent 1px), linear-gradient(90deg, oklch(1 0 0 / 0.5) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 75%)",
        }}
      />
    </div>
  );
}

/* ---------- header ---------- */

const NAV = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

function TopBar() {
  return (
    <div className="hidden md:block border-b border-white/5 bg-black/20 backdrop-blur-md text-xs">
      <div className="mx-auto max-w-7xl px-6 py-2 flex items-center justify-between text-muted-foreground">
        <div className="flex items-center gap-5">
          <span className="flex items-center gap-1.5"><Clock size={13} className="text-[color:var(--neon)]" /> 10:30 AM – 8:30 PM</span>
          <span className="flex items-center gap-1.5"><MapPin size={13} className="text-[color:var(--neon)]" /> Main Market Road, Sector 12</span>
        </div>
        <a href={`tel:${PHONE_TEL}`} className="flex items-center gap-1.5 hover:text-white transition">
          <Phone size={13} className="text-[color:var(--neon)]" /> {PHONE}
        </a>
      </div>
    </div>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={`sticky top-0 z-50 transition-all ${scrolled ? "py-2" : "py-3"}`}>
      <TopBar />
      <div className="px-4 pt-3">
        <nav className={`mx-auto max-w-7xl glass-strong rounded-full px-4 sm:px-6 py-3 flex items-center justify-between transition-all ${scrolled ? "shadow-[0_10px_40px_-10px_oklch(0.05_0.1_295/0.6)]" : ""}`}>
          <a href="#home" className="flex items-center gap-2.5">
            <span className="relative grid place-items-center w-9 h-9 rounded-xl"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
              <Eye size={18} className="text-white" />
            </span>
            <span className="font-display text-lg font-bold tracking-tight">
              Vio<span className="text-gradient">Vision</span>
            </span>
          </a>
          <ul className="hidden lg:flex items-center gap-1">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="px-4 py-2 rounded-full text-sm text-muted-foreground hover:text-white hover:bg-white/5 transition">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-2">
            <a href={`tel:${PHONE_TEL}`} className="hidden sm:inline-flex btn-neon text-sm !py-2.5 !px-5">
              <Phone size={14} className="mr-2 inline" /> Call Now
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="lg:hidden grid place-items-center w-10 h-10 rounded-full glass"
              aria-label="Toggle menu"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </nav>
        {open && (
          <div className="lg:hidden mx-auto max-w-7xl mt-2 glass-strong rounded-2xl p-3 animate-fade-up">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="block px-4 py-3 rounded-xl text-sm hover:bg-white/5"
              >
                {n.label}
              </a>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}

/* ---------- hero ---------- */

function Hero() {
  return (
    <section id="home" className="relative pt-8 lg:pt-12 pb-20 lg:pb-28 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="relative min-h-[560px] lg:min-h-[640px]">
          {/* floating purple orbs */}
          <div aria-hidden className="absolute inset-0 pointer-events-none">
            <div className="absolute rounded-full animate-float" style={{ width: 56, height: 56, top: "18%", left: "44%", background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.18 305), oklch(0.45 0.25 295))", boxShadow: "0 0 40px oklch(0.7 0.28 305 / 0.7)" }} />
            <div className="absolute rounded-full animate-float-slow" style={{ width: 38, height: 38, top: "8%", right: "22%", background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.18 305), oklch(0.45 0.25 295))", boxShadow: "0 0 30px oklch(0.7 0.28 305 / 0.7)" }} />
            <div className="absolute rounded-full animate-float" style={{ width: 28, height: 28, top: "55%", left: "38%", background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.18 305), oklch(0.45 0.25 295))", boxShadow: "0 0 24px oklch(0.7 0.28 305 / 0.7)" }} />
            <div className="absolute rounded-full animate-float-slow" style={{ width: 44, height: 44, bottom: "18%", left: "30%", background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.18 305), oklch(0.45 0.25 295))", boxShadow: "0 0 34px oklch(0.7 0.28 305 / 0.7)" }} />
            <div className="absolute rounded-full animate-float" style={{ width: 22, height: 22, top: "40%", right: "30%", background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.18 305), oklch(0.45 0.25 295))", boxShadow: "0 0 20px oklch(0.7 0.28 305 / 0.7)" }} />

            {/* flowing neon curve */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 640" fill="none" preserveAspectRatio="none">
              <defs>
                <linearGradient id="heroLine" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="oklch(0.85 0.22 305)" stopOpacity="0" />
                  <stop offset="50%" stopColor="oklch(0.78 0.28 308)" stopOpacity="1" />
                  <stop offset="100%" stopColor="oklch(0.6 0.25 290)" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path d="M 80 480 C 320 360, 520 560, 740 360 S 1100 280, 1160 180"
                stroke="url(#heroLine)" strokeWidth="2" fill="none" />
            </svg>
          </div>

          {/* top-right camera */}
          <img
            src={camRight}
            alt="CCTV camera"
            width={1024}
            height={1024}
            className="hidden sm:block absolute -top-6 right-0 lg:-right-10 w-[260px] sm:w-[340px] lg:w-[460px] rotate-[8deg] drop-shadow-[0_30px_60px_oklch(0.05_0.1_295/0.7)] pointer-events-none select-none"
          />

          {/* bottom-left camera */}
          <img
            src={camLeft}
            alt="CCTV camera"
            width={1024}
            height={1024}
            loading="lazy"
            className="hidden sm:block absolute -bottom-6 -left-6 lg:-left-12 w-[220px] sm:w-[300px] lg:w-[400px] -rotate-[6deg] drop-shadow-[0_30px_60px_oklch(0.05_0.1_295/0.7)] pointer-events-none select-none"
          />

          {/* glass headline card */}
          <div className="relative z-10 reveal max-w-xl lg:max-w-[640px] mt-6 lg:mt-12">
            <div className="glass-strong rounded-[2rem] p-7 sm:p-10 relative overflow-hidden">
              <div aria-hidden className="absolute -top-24 -left-24 w-64 h-64 rounded-full blur-3xl opacity-60"
                style={{ background: "oklch(0.6 0.28 305 / 0.5)" }} />
              <h1 className="relative text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
                Protecting <span className="text-gradient">Your Business</span>
                <br />
                Securing <span className="text-gradient">Your Trust</span>
              </h1>
              <p className="relative mt-5 text-base sm:text-lg text-muted-foreground max-w-md">
                Wholesale CCTV, DVR/NVR & complete security solutions with cutting-edge
                monitoring systems and round-the-clock expert support.
              </p>
              <div className="relative mt-7 flex flex-wrap items-center gap-3">
                <a href={`tel:${PHONE_TEL}`} className="btn-neon inline-flex items-center group">
                  Call Now
                  <ArrowRight size={16} className="ml-2 -rotate-45 transition-transform group-hover:translate-x-0.5" />
                </a>
                <a href="#services" className="btn-ghost-glow inline-flex items-center">
                  Explore <ArrowRight size={16} className="ml-2" />
                </a>
              </div>
            </div>

            {/* stats below */}
            <div className="mt-8 grid grid-cols-3 max-w-md gap-3">
              {[
                { k: "12+", v: "Years" },
                { k: "5K+", v: "Clients" },
                { k: "99%", v: "Uptime" },
              ].map((s) => (
                <div key={s.v} className="glass rounded-2xl p-4 text-center">
                  <div className="text-2xl font-bold text-gradient">{s.k}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- about ---------- */

function About() {
  const stats = [
    { icon: Users, k: "5,000+", v: "Happy Customers" },
    { icon: Package, k: "1,200+", v: "Bulk Orders Shipped" },
    { icon: Award, k: "12 Years", v: "Trusted Service" },
    { icon: Headphones, k: "24/7", v: "Customer Support" },
  ];
  return (
    <section id="about" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-10 items-center">
        <div className="reveal relative">
          <div className="absolute -inset-4 rounded-[2rem] blur-3xl opacity-50"
            style={{ background: "radial-gradient(circle, oklch(0.6 0.26 305 / 0.6), transparent 60%)" }} />
          <div className="relative glass-strong rounded-[1.75rem] p-2">
            <img
              src={aboutSide}
              alt="Wholesale CCTV warehouse"
              width={1024}
              height={1280}
              loading="lazy"
              className="w-full h-[460px] object-cover rounded-[1.4rem]"
            />
          </div>
        </div>

        <div className="reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">About Us</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            A premium <span className="text-gradient">wholesale partner</span> for security.
          </h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">
            VioVision is one of the region's most trusted wholesale CCTV and security
            equipment distributors. We supply retailers, integrators and businesses with
            authentic, high-grade products at honest wholesale prices — backed by
            dedicated support that has earned thousands of long-term clients.
          </p>
          <ul className="mt-6 space-y-3 text-sm">
            {[
              "Authentic brands with full manufacturer warranty",
              "Best-in-market wholesale pricing on bulk orders",
              "Dedicated account manager for every business client",
            ].map((t) => (
              <li key={t} className="flex items-start gap-3">
                <span className="mt-0.5 grid place-items-center w-5 h-5 rounded-full"
                  style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
                  <ShieldCheck size={12} className="text-white" />
                </span>
                <span className="text-foreground/90">{t}</span>
              </li>
            ))}
          </ul>

          <div className="mt-8 grid grid-cols-2 gap-3">
            {stats.map(({ icon: Icon, k, v }) => (
              <div key={v} className="glass rounded-2xl p-4 card-hover">
                <Icon size={20} className="text-[color:var(--neon)]" />
                <div className="mt-2 text-xl font-bold">{k}</div>
                <div className="text-xs text-muted-foreground">{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- services ---------- */

const SERVICES = [
  {
    icon: Camera,
    title: "Wholesale CCTV Supply",
    desc: "Bulk supply of IP, HD analog, dome, bullet and PTZ cameras from top global brands at true wholesale rates.",
  },
  {
    icon: HardDrive,
    title: "DVR & NVR Systems",
    desc: "Full range of 4 to 64-channel recorders with cloud backup, mobile streaming and AI-powered detection.",
  },
  {
    icon: Wrench,
    title: "Installation & Maintenance",
    desc: "Certified technicians for on-site installation, configuration and annual maintenance contracts.",
  },
  {
    icon: Network,
    title: "Networking & Accessories",
    desc: "PoE switches, cables, connectors, hard drives and every accessory you need — all under one roof.",
  },
  {
    icon: ShieldCheck,
    title: "Custom Security Solutions",
    desc: "Tailored surveillance design for shops, offices, factories and residential complexes.",
  },
  {
    icon: Headphones,
    title: "Dealer & Reseller Support",
    desc: "Special dealer pricing, training resources and priority support for resellers and integrators.",
  },
];

function Services() {
  return (
    <section id="services" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">What we offer</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            Complete <span className="text-gradient">security solutions</span> for every scale.
          </h2>
          <p className="mt-4 text-muted-foreground">
            From a single camera to enterprise-wide surveillance — we have the products,
            pricing and people to make it happen.
          </p>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} className="reveal glass rounded-3xl p-7 card-hover group relative overflow-hidden" style={{ transitionDelay: `${i * 60}ms` }}>
              <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: "radial-gradient(circle, oklch(0.7 0.26 305 / 0.45), transparent 70%)" }} />
              <div className="relative">
                <div className="grid place-items-center w-12 h-12 rounded-2xl"
                  style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
                  <Icon size={22} className="text-white" />
                </div>
                <h3 className="mt-5 text-lg font-semibold">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{desc}</p>
                <a href="#contact" className="mt-5 inline-flex items-center text-sm text-[color:var(--neon)] font-medium group/link">
                  Enquire now
                  <ArrowRight size={14} className="ml-1 transition-transform group-hover/link:translate-x-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- trust ---------- */

function Trust() {
  const badges = [
    { icon: Award, t: "Trusted Wholesale Seller" },
    { icon: ShieldCheck, t: "Authentic Quality Products" },
    { icon: Package, t: "Best Wholesale Pricing" },
    { icon: Headphones, t: "Fast Customer Support" },
  ];
  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-10 items-center">
        <div className="reveal relative group cursor-pointer">
          <div className="absolute -inset-4 rounded-[2rem] blur-3xl opacity-60"
            style={{ background: "radial-gradient(circle, oklch(0.65 0.28 305 / 0.55), transparent 60%)" }} />
          <div className="relative glass-strong rounded-[1.75rem] overflow-hidden">
            <img src={gal1} alt="Shop video preview" width={1024} height={1024} loading="lazy"
              className="w-full h-[420px] object-cover" />
            <div className="absolute inset-0 grid place-items-center bg-black/30 group-hover:bg-black/20 transition">
              <div className="grid place-items-center w-20 h-20 rounded-full transition-transform group-hover:scale-110"
                style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow-strong)" }}>
                <PlayCircle size={36} className="text-white" />
              </div>
            </div>
            <div className="absolute bottom-5 left-5 glass rounded-xl px-3 py-2 text-xs">
              Tour our showroom
            </div>
          </div>
        </div>

        <div className="reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">Why customers trust us</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            Built on <span className="text-gradient">reliability</span>, run on relationships.
          </h2>
          <p className="mt-4 text-muted-foreground">
            For over a decade, dealers and businesses have chosen us for one simple
            reason — we deliver on every promise. Honest pricing, original products and
            a team that's always reachable.
          </p>
          <div className="mt-7 grid sm:grid-cols-2 gap-3">
            {badges.map(({ icon: Icon, t }) => (
              <div key={t} className="glass rounded-2xl p-4 flex items-center gap-3 card-hover">
                <span className="grid place-items-center w-10 h-10 rounded-xl"
                  style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
                  <Icon size={18} className="text-white" />
                </span>
                <span className="text-sm font-medium">{t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- gallery ---------- */

function Gallery() {
  const items = [
    { src: gal1, h: "row-span-2", alt: "Modern control room" },
    { src: gal2, h: "", alt: "CCTV showroom wall" },
    { src: gal3, h: "", alt: "Dome camera close-up" },
    { src: gal4, h: "row-span-2", alt: "DVR NVR rack" },
    { src: gal5, h: "", alt: "Installation in progress" },
  ];
  return (
    <section id="gallery" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">Gallery</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            Inside our <span className="text-gradient">showroom & work</span>
          </h2>
        </div>

        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-4">
          {items.map((it, i) => (
            <div key={i} className={`relative reveal overflow-hidden rounded-3xl glass-strong group ${it.h} ${i === 0 ? "col-span-2" : ""}`}
              style={{ transitionDelay: `${i * 60}ms` }}>
              <img src={it.src} alt={it.alt} loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-70" />
              <div className="absolute bottom-4 left-4 text-sm font-medium opacity-0 group-hover:opacity-100 transition translate-y-2 group-hover:translate-y-0 duration-500">
                {it.alt}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- reviews ---------- */

const REVIEWS = [
  {
    name: "Rohit Sharma",
    role: "Retail Dealer, Delhi",
    text: "Best wholesale rates I've found in years. Stock is always available and delivery is faster than promised. Highly recommended for serious dealers.",
    avatar: "https://i.pravatar.cc/120?img=12",
  },
  {
    name: "Priya Mehta",
    role: "Store Owner, Jaipur",
    text: "We installed 24 cameras across our outlets through VioVision. The team handled everything end-to-end. Quality is genuinely top tier.",
    avatar: "https://i.pravatar.cc/120?img=47",
  },
  {
    name: "Arjun Verma",
    role: "Integrator, Mumbai",
    text: "Their dealer support team is fantastic. Quick replies, honest pricing, and the products are 100% original with warranty.",
    avatar: "https://i.pravatar.cc/120?img=33",
  },
];

function Reviews() {
  return (
    <section id="reviews" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">Reviews</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            Loved by <span className="text-gradient">dealers & businesses</span>
          </h2>
        </div>

        <div className="mt-14 grid md:grid-cols-3 gap-5">
          {REVIEWS.map((r, i) => (
            <div key={r.name} className="reveal glass rounded-3xl p-7 card-hover" style={{ transitionDelay: `${i * 80}ms` }}>
              <div className="flex items-center gap-1 text-[color:var(--neon)]">
                {Array.from({ length: 5 }).map((_, k) => <Star key={k} size={16} fill="currentColor" stroke="none" />)}
              </div>
              <p className="mt-4 text-foreground/90 leading-relaxed text-sm">"{r.text}"</p>
              <div className="mt-6 flex items-center gap-3">
                <img src={r.avatar} alt={r.name} className="w-11 h-11 rounded-full object-cover ring-2 ring-[color:var(--neon)]/40" />
                <div>
                  <div className="font-semibold text-sm">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- contact ---------- */

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <div className="text-xs font-semibold tracking-[0.3em] text-[color:var(--neon)] uppercase">Contact</div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold">
            Let's <span className="text-gradient">talk security</span>
          </h2>
          <p className="mt-4 text-muted-foreground">Drop us a message or visit our shop. Our team responds within minutes.</p>
        </div>

        <div className="mt-14 grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 space-y-4 reveal">
            {[
              { icon: Phone, t: "Phone", v: PHONE, href: `tel:${PHONE_TEL}` },
              { icon: MapPin, t: "Location", v: "Main Market Road, Sector 12, City — 000000" },
              { icon: Clock, t: "Opening Hours", v: "Mon – Sun · 10:30 AM – 8:30 PM" },
              { icon: Mail, t: "Email", v: "hello@viovision.in", href: "mailto:hello@viovision.in" },
            ].map(({ icon: Icon, t, v, href }) => {
              const inner = (
                <>
                  <span className="grid place-items-center w-11 h-11 rounded-xl shrink-0"
                    style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
                    <Icon size={18} className="text-white" />
                  </span>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">{t}</div>
                    <div className="font-medium mt-0.5">{v}</div>
                  </div>
                </>
              );
              return href ? (
                <a key={t} href={href} className="glass rounded-2xl p-5 flex items-center gap-4 card-hover">{inner}</a>
              ) : (
                <div key={t} className="glass rounded-2xl p-5 flex items-center gap-4">{inner}</div>
              );
            })}

            <div className="glass-strong rounded-2xl overflow-hidden h-56">
              <iframe
                title="Shop location"
                src="https://www.openstreetmap.org/export/embed.html?bbox=77.20%2C28.60%2C77.25%2C28.65&layer=mapnik"
                className="w-full h-full grayscale-[40%] contrast-110"
                loading="lazy"
              />
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              setTimeout(() => setSent(false), 4000);
              (e.target as HTMLFormElement).reset();
            }}
            className="lg:col-span-3 glass-strong rounded-3xl p-7 sm:p-9 reveal"
          >
            <h3 className="text-xl font-semibold">Send an inquiry</h3>
            <p className="text-sm text-muted-foreground mt-1">We'll get back within a few hours.</p>

            <div className="mt-6 grid sm:grid-cols-2 gap-4">
              <Field label="Your Name" name="name" placeholder="Rahul Kumar" />
              <Field label="Phone" name="phone" placeholder="+91 9XXXX XXXXX" />
            </div>
            <div className="mt-4">
              <label className="block text-xs uppercase tracking-wider text-muted-foreground mb-2">Message</label>
              <textarea
                required
                rows={5}
                placeholder="Tell us what you need — quantity, location, timeline…"
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-sm placeholder:text-muted-foreground/70 focus:outline-none focus:border-[color:var(--neon)]/60 focus:ring-2 focus:ring-[color:var(--neon)]/20 transition"
              />
            </div>
            <div className="mt-6 flex items-center justify-between gap-4 flex-wrap">
              <div className="text-xs text-muted-foreground">By submitting you agree to be contacted about your inquiry.</div>
              <button type="submit" className="btn-neon inline-flex items-center">
                Send Inquiry <ArrowRight size={16} className="ml-2" />
              </button>
            </div>
            {sent && (
              <div className="mt-5 glass rounded-xl px-4 py-3 text-sm text-[color:var(--neon)]">
                ✓ Thanks! Your inquiry has been received.
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, name, placeholder }: { label: string; name: string; placeholder: string }) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-wider text-muted-foreground mb-2">{label}</label>
      <input
        required
        name={name}
        type="text"
        placeholder={placeholder}
        className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-sm placeholder:text-muted-foreground/70 focus:outline-none focus:border-[color:var(--neon)]/60 focus:ring-2 focus:ring-[color:var(--neon)]/20 transition"
      />
    </div>
  );
}

/* ---------- footer ---------- */

function Footer() {
  return (
    <footer className="relative pt-16 pb-10">
      <div className="mx-auto max-w-7xl px-6">
        <div className="glass-strong rounded-3xl p-8 sm:p-10 grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <a href="#home" className="flex items-center gap-2.5">
              <span className="grid place-items-center w-9 h-9 rounded-xl"
                style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}>
                <Eye size={18} className="text-white" />
              </span>
              <span className="font-display text-lg font-bold">Vio<span className="text-gradient">Vision</span></span>
            </a>
            <p className="mt-4 text-sm text-muted-foreground max-w-sm">
              Premium wholesale CCTV and security solutions — trusted by dealers,
              businesses and homes across the country.
            </p>
            <div className="mt-5 flex items-center gap-2">
              {[Facebook, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="grid place-items-center w-10 h-10 rounded-full glass hover:border-[color:var(--neon)]/60 transition" aria-label="social">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold mb-4">Quick Links</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {NAV.map((n) => (
                <li key={n.href}><a href={n.href} className="hover:text-white transition">{n.label}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <div className="text-sm font-semibold mb-4">Get in touch</div>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2"><Phone size={14} className="mt-0.5 text-[color:var(--neon)]" />{PHONE}</li>
              <li className="flex items-start gap-2"><Clock size={14} className="mt-0.5 text-[color:var(--neon)]" />10:30 AM – 8:30 PM</li>
              <li className="flex items-start gap-2"><MapPin size={14} className="mt-0.5 text-[color:var(--neon)]" />Sector 12, City</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
          <div>© {new Date().getFullYear()} VioVision. All rights reserved.</div>
          <div>Crafted with care · Premium security since 2012</div>
        </div>
      </div>
    </footer>
  );
}

/* ---------- whatsapp float ---------- */

function WhatsAppFAB() {
  return (
    <a
      href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi VioVision, I'd like to enquire about your products.")}`}
      target="_blank" rel="noreferrer"
      className="fixed bottom-6 right-6 z-50 group"
      aria-label="Chat on WhatsApp"
    >
      <span className="absolute inset-0 rounded-full animate-pulse-glow"
        style={{ background: "radial-gradient(circle, oklch(0.7 0.28 305 / 0.6), transparent 70%)" }} />
      <span className="relative grid place-items-center w-14 h-14 rounded-full transition-transform group-hover:scale-110"
        style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow-strong)" }}>
        <MessageCircle size={24} className="text-white" />
      </span>
    </a>
  );
}

/* ---------- page ---------- */

function Home() {
  useReveal();
  return (
    <div className="relative min-h-screen">
      <BackgroundFX />
      <Header />
      <main>
        <Hero />
        <About />
        <Services />
        <Trust />
        <Gallery />
        <Reviews />
        <Contact />
      </main>
      <Footer />
      <WhatsAppFAB />
    </div>
  );
}
